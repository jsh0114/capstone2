package com.capstone.teamProj_10.apiTest.web;

import com.capstone.teamProj_10.apiTest.item.Product;
import com.capstone.teamProj_10.apiTest.service.ItemService;
import com.capstone.teamProj_10.apiTest.user.UserCreateForm;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ViewController {
    private final SearchRequestController searchRequestController;
    private final ItemService itemService;


    @GetMapping("/searchResult")
    public String searchResult(Model model) {
        List<Product> productList = itemService.findItems(); // 모든 상품 목록을 가져옵니다.
        model.addAttribute("productList", productList); // 상품 목록을 모델에 추가합니다.
        return "searchResult";
    }

    @GetMapping("/search")
    public String searchProduct(@RequestParam String query, Model model) {
        List<Product> productList = searchRequestController.getItems(query);
        model.addAttribute("productList", productList);
        model.addAttribute("query", query);
        return "/searchResult"; // 뷰 이름
    }

    @GetMapping("/cpu")
    public String cpu(Model model) {
        List<Product> productList = itemService.findCpuItems();
        model.addAttribute("productList", productList);
        return "/Products/cpu";
    }

    @GetMapping("/gpu")
    public String gpu(Model model) {
        List<Product> productList = itemService.findGpuItems();
        model.addAttribute("productList", productList);
        return "/Products/gpu";
    }

    @GetMapping("/ssd")
    public String ssd(Model model) {
        List<Product> productList = itemService.findSsdItems();
        model.addAttribute("productList", productList);
        return "/Products/ssd";
    }

    @GetMapping("/hdd")
    public String hdd(Model model) {
        List<Product> productList = itemService.findHddItems();
        model.addAttribute("productList", productList);
        return "/Products/hdd";
    }

    @GetMapping("/ram")
    public String ram(Model model) {
        List<Product> productList = itemService.findRamItems();
        model.addAttribute("productList", productList);
        return "/Products/ram";
    }

    @GetMapping("/computercase")
    public String computercase(Model model) {
        List<Product> productList = itemService.findComputercaseItems();
        model.addAttribute("productList", productList);
        return "/Products/computercase";
    }

    @GetMapping("/mainboard")
    public String mainboard(Model model) {
        List<Product> productList = itemService.findMainboardItems();
        model.addAttribute("productList", productList);
        return "/Products/mainboard";
    }

    @GetMapping("/power")
    public String power(Model model) {
        List<Product> productList = itemService.findPowerItems();
        model.addAttribute("productList", productList);
        return "/Products/power";
    }

    @GetMapping("/cooler")
    public String cooler(Model model) {
        List<Product> productList = itemService.findCoolerItems();
        model.addAttribute("productList", productList);
        return "/Products/cooler";
    }

    @GetMapping("/monitor")
    public String monitor(Model model) {
        List<Product> productList = itemService.findMonitorItems();
        model.addAttribute("productList", productList);
        return "/Products/monitor";
    }

    @GetMapping("/mypage")
    public String mypage() {
        return "/mypage";
    }

    @GetMapping("/cart")
    public String cart() {
        return "/cart";
    }
}