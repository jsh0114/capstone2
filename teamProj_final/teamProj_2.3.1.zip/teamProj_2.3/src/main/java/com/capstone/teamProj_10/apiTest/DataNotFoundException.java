package com.capstone.teamProj_10.apiTest;

public class DataNotFoundException extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	public DataNotFoundException(String message) {
		super(message);
	}
}
