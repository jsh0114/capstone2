package com.capstone.teamProj_10.apiTest.service;

import com.capstone.teamProj_10.apiTest.item.ItemDto;
import com.capstone.teamProj_10.apiTest.item.Product;
import com.capstone.teamProj_10.apiTest.repository.ItemRepository;
import com.capstone.teamProj_10.apiTest.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ItemService {
    private final ItemRepository itemRepository;
    private final ProductRepository productRepository;
    @Transactional
    public void saveItem(Product product) {
        itemRepository.save(product);
    }
    public List<Product> findItems() {
        return itemRepository.findAll();
    }
    public Product findOne(Long itemId) {
        return itemRepository.findOne(itemId);
    }


    @Transactional
    public void updateItem(Long productId, ItemDto itemDto) {
        Product item = findOne(productId);
        item.updateByItemDto(itemDto);
    }

    @Transactional
    public Long updateBySearch(Long id, ItemDto itemDto) {
        Product product = productRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("아이디가 존재하지 않습니다.")
        );
        product.updateByItemDto(itemDto);
        return id;
    }

}