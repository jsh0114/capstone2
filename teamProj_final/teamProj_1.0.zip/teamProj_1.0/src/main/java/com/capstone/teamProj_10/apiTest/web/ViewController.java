package com.capstone.teamProj_10.apiTest.web;

import com.capstone.teamProj_10.apiTest.item.Product;
import com.capstone.teamProj_10.apiTest.service.ItemService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ViewController {
    private final SearchRequestController searchRequestController;
    private final ItemService itemService;


    @GetMapping("/searchResult")
    public String searchResult(Model model) {
        List<Product> productList = itemService.findItems(); // 모든 상품 목록을 가져옵니다.
        model.addAttribute("productList", productList); // 상품 목록을 모델에 추가합니다.
        return "searchResult";
    }
    @GetMapping("/search")
    public String searchProduct(@RequestParam String query, Model model) {
        List<Product> productList = searchRequestController.getItems(query);
        model.addAttribute("productList", productList);
        model.addAttribute("query", query);
        return "/searchResult"; // 뷰 이름
    }
}
